require("dotenv").config();

const path = require("path");
const fs = require("fs");
const http = require("http");
const express = require("express");
const cookieParser = require("cookie-parser");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const mongoose = require("mongoose");
const multer = require("multer");
const { createClient } = require("redis");
const { Server } = require("socket.io");

const PORT = Number(process.env.PORT || 3000);
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: true, credentials: true },
  transports: ["websocket", "polling"],
  pingInterval: 25000,
  pingTimeout: 20000
});

app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));
app.use(cookieParser());

const publicDir = path.join(__dirname, "public");
const uploadDir = path.join(publicDir, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, uploadDir),
  filename: (_, file, cb) => {
    const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");
    cb(null, `${Date.now()}-${safe}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_, file, cb) => {
    if (!/^image\\/(jpeg|png|webp)$/.test(file.mimetype)) {
      return cb(new Error("Only JPG, PNG or WEBP images are allowed."));
    }
    cb(null, true);
  }
});

app.use("/uploads", express.static(uploadDir, {
  maxAge: "7d",
  immutable: true
}));
app.use(express.static(publicDir, { maxAge: "1h" }));

const playerSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  phone: { type: String, required: true, trim: true },
  village: { type: String, required: true, trim: true },
  role: { type: String, enum: ["Batsman", "Bowler", "All-Rounder", "Wicket-Keeper"], required: true },
  photoUrl: { type: String, required: true },
  utr: { type: String, required: true, unique: true, index: true },
  paymentScreenshotUrl: { type: String, default: "" },
  status: { type: String, enum: ["PENDING", "CONFIRMED", "SOLD", "UNSOLD"], default: "PENDING", index: true },
  auctionEligible: { type: Boolean, default: false, index: true },
  soldTeam: { type: String, default: "" },
  soldPoints: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now }
});

const teamSchema = new mongoose.Schema({
  code: { type: String, unique: true, required: true },
  name: { type: String, required: true },
  totalPoints: { type: Number, default: 10000 },
  spentPoints: { type: Number, default: 0 },
  playerCount: { type: Number, default: 0 },
  maxPlayers: { type: Number, default: 25 }
});

const auctionSchema = new mongoose.Schema({
  key: { type: String, unique: true, default: "main" },
  status: { type: String, enum: ["IDLE", "LIVE", "SOLD", "UNSOLD"], default: "IDLE" },
  currentPlayerId: { type: mongoose.Schema.Types.ObjectId, default: null },
  baseBid: { type: Number, default: 200 },
  currentBid: { type: Number, default: 0 },
  highestTeam: { type: String, default: "" },
  bidIncrement: { type: Number, default: 10 },
  bidHistory: [{
    team: String,
    amount: Number,
    at: Date
  }],
  updatedAt: { type: Date, default: Date.now }
});

const Player = mongoose.model("Player", playerSchema);
const Team = mongoose.model("Team", teamSchema);
const Auction = mongoose.model("Auction", auctionSchema);

const DEFAULT_TEAMS = [
  ["RCJ", "RCJ Warriors"],
  ["JCB", "JCB Titans"],
  ["SS", "Sandur Strikers"],
  ["HH", "Hospet Heroes"],
  ["BB", "Bellary Blasters"],
  ["MW", "Mining Warriors"],
  ["KK", "Kudligi Kings"],
  ["TG", "Toranagallu"],
];

async function seedTeams() {
  for (const [code, name] of DEFAULT_TEAMS) {
    await Team.updateOne(
      { code },
      { $setOnInsert: { code, name, totalPoints: 10000, maxPlayers: 25 } },
      { upsert: true }
    );
  }
  await Auction.updateOne(
    { key: "main" },
    { $setOnInsert: { key: "main", status: "IDLE", baseBid: 200, bidIncrement: 10 } },
    { upsert: true }
  );
}

function signAdmin() {
  return jwt.sign({ admin: true }, process.env.JWT_SECRET, { expiresIn: "12h" });
}

function requireAdmin(req, res, next) {
  try {
    const token = req.cookies.sgppl_admin;
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    if (!payload.admin) throw new Error("Not admin");
    next();
  } catch {
    res.status(401).json({ error: "Admin login required." });
  }
}

function safePlayer(p) {
  return {
    id: p._id,
    name: p.name,
    phone: p.phone,
    village: p.village,
    role: p.role,
    photoUrl: p.photoUrl,
    utr: p.utr,
    status: p.status,
    auctionEligible: p.auctionEligible,
    soldTeam: p.soldTeam,
    soldPoints: p.soldPoints,
    createdAt: p.createdAt
  };
}

async function getPublicState() {
  const [auction, teams, players] = await Promise.all([
    Auction.findOne({ key: "main" }).lean(),
    Team.find().sort({ code: 1 }).lean(),
    Player.find({ auctionEligible: true })
      .select("name village role photoUrl status soldTeam soldPoints createdAt")
      .sort({ createdAt: 1 })
      .lean()
  ]);

  let currentPlayer = null;
  if (auction?.currentPlayerId) {
    const p = await Player.findById(auction.currentPlayerId).lean();
    if (p) currentPlayer = safePlayer(p);
  }

  return {
    auction: auction || null,
    currentPlayer,
    teams: teams.map(t => ({
      code: t.code,
      name: t.name,
      totalPoints: t.totalPoints,
      spentPoints: t.spentPoints,
      remainingPoints: t.totalPoints - t.spentPoints,
      playerCount: t.playerCount,
      maxPlayers: t.maxPlayers
    })),
    players
  };
}

async function broadcastState() {
  io.to("auction-room").emit("auction:state", await getPublicState());
}

app.post("/api/register", upload.fields([
  { name: "photo", maxCount: 1 },
  { name: "paymentScreenshot", maxCount: 1 }
]), async (req, res) => {
  try {
    const { name, phone, village, role, utr } = req.body;
    if (!name || !phone || !village || !role || !utr || !req.files?.photo?.[0]) {
      return res.status(400).json({ error: "Name, phone, village, role, UTR and player photo are required." });
    }

    const existing = await Player.findOne({ utr: utr.trim() });
    if (existing) {
      return res.status(409).json({ error: "This UTR is already registered." });
    }

    const photoUrl = `/uploads/${req.files.photo[0].filename}`;
    const paymentScreenshotUrl = req.files.paymentScreenshot?.[0]
      ? `/uploads/${req.files.paymentScreenshot[0].filename}`
      : "";

    const player = await Player.create({
      name, phone, village, role,
      utr: utr.trim(),
      photoUrl,
      paymentScreenshotUrl
    });

    res.status(201).json({
      message: "Registration submitted. Keep your UTR safe. Admin will verify it.",
      playerId: player._id
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post("/api/admin/login", async (req, res) => {
  const { username, password } = req.body;
  const expectedUser = process.env.ADMIN_USERNAME || "admin";
  const expectedPassword = process.env.ADMIN_PASSWORD || "change-me";

  if (username !== expectedUser || password !== expectedPassword) {
    return res.status(401).json({ error: "Invalid admin login." });
  }

  res.cookie("sgppl_admin", signAdmin(), {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 12 * 60 * 60 * 1000
  });
  res.json({ ok: true });
});

app.post("/api/admin/logout", requireAdmin, (req, res) => {
  res.clearCookie("sgppl_admin");
  res.json({ ok: true });
});

// Admin pastes the UTR received in the UPI/bank transaction list.
// Exact UTR match automatically confirms the player.
app.post("/api/admin/verify-utr", requireAdmin, async (req, res) => {
  const utr = String(req.body.utr || "").trim();
  if (!utr) return res.status(400).json({ error: "Enter the received UTR." });

  const player = await Player.findOne({ utr });
  if (!player) {
    return res.status(404).json({ error: "UTR NOT FOUND. Check the UTR and try again." });
  }

  if (player.status === "CONFIRMED" || player.status === "SOLD") {
    return res.json({ message: "UTR already verified.", player: safePlayer(player) });
  }

  player.status = "CONFIRMED";
  player.auctionEligible = true;
  await player.save();

  await broadcastState();
  res.json({ message: "Payment matched. Player is now auction eligible.", player: safePlayer(player) });
});

app.get("/api/admin/players", requireAdmin, async (req, res) => {
  const players = await Player.find().sort({ createdAt: -1 }).lean();
  res.json(players.map(safePlayer));
});

app.get("/api/public/state", async (req, res) => {
  res.json(await getPublicState());
});

app.get("/api/admin/state", requireAdmin, async (req, res) => {
  const state = await getPublicState();
  const players = await Player.find().sort({ createdAt: -1 }).lean();
  res.json({ ...state, allPlayers: players.map(safePlayer) });
});

async function adminAuctionAction(action, body) {
  const auction = await Auction.findOne({ key: "main" });
  if (!auction) throw new Error("Auction not initialized.");

  if (action === "start") {
    const player = await Player.findOne({
      _id: body.playerId,
      auctionEligible: true,
      status: "CONFIRMED"
    });
    if (!player) throw new Error("Player is not auction eligible.");

    auction.status = "LIVE";
    auction.currentPlayerId = player._id;
    auction.currentBid = 0;
    auction.highestTeam = "";
    auction.baseBid = Number(body.baseBid || 200);
    auction.bidIncrement = Number(body.bidIncrement || 10);
    auction.bidHistory = [];
    auction.updatedAt = new Date();
    await auction.save();
    return;
  }

  if (action === "bid") {
    if (auction.status !== "LIVE" || !auction.currentPlayerId) {
      throw new Error("No live player.");
    }

    const team = await Team.findOne({ code: body.teamCode });
    if (!team) throw new Error("Invalid team.");

    if (team.playerCount >= team.maxPlayers) {
      throw new Error(`${team.code} already has ${team.maxPlayers} players.`);
    }

    const nextBid = auction.currentBid === 0
      ? auction.baseBid
      : auction.currentBid + auction.bidIncrement;

    const remaining = team.totalPoints - team.spentPoints;
    if (remaining < nextBid) {
      throw new Error(`${team.code} does not have enough points for ${nextBid}.`);
    }

    auction.currentBid = nextBid;
    auction.highestTeam = team.code;
    auction.bidHistory.push({
      team: team.code,
      amount: nextBid,
      at: new Date()
    });
    auction.updatedAt = new Date();
    await auction.save();
    return;
  }

  if (action === "sold") {
    if (auction.status !== "LIVE" || !auction.currentPlayerId || !auction.highestTeam || !auction.currentBid) {
      throw new Error("There is no valid highest bid to sell.");
    }

    const team = await Team.findOne({ code: auction.highestTeam });
    const player = await Player.findById(auction.currentPlayerId);

    if (!team || !player) throw new Error("Auction data is invalid.");
    if (team.playerCount >= team.maxPlayers) throw new Error("Team has reached 25 players.");
    if (team.totalPoints - team.spentPoints < auction.currentBid) {
      throw new Error("Team no longer has enough points.");
    }

    team.spentPoints += auction.currentBid;
    team.playerCount += 1;
    await team.save();

    player.status = "SOLD";
    player.auctionEligible = true;
    player.soldTeam = team.code;
    player.soldPoints = auction.currentBid;
    await player.save();

    auction.status = "SOLD";
    auction.updatedAt = new Date();
    await auction.save();
    return;
  }

  if (action === "unsold") {
    if (auction.status !== "LIVE" || !auction.currentPlayerId) throw new Error("No live player.");
    await Player.findByIdAndUpdate(auction.currentPlayerId, { status: "UNSOLD" });

    auction.status = "UNSOLD";
    auction.updatedAt = new Date();
    await auction.save();
    return;
  }

  if (action === "reset") {
    auction.status = "IDLE";
    auction.currentPlayerId = null;
    auction.currentBid = 0;
    auction.highestTeam = "";
    auction.bidHistory = [];
    auction.updatedAt = new Date();
    await auction.save();
    return;
  }

  throw new Error("Unknown auction action.");
}

app.post("/api/admin/auction/:action", requireAdmin, async (req, res) => {
  try {
    await adminAuctionAction(req.params.action, req.body || {});
    await broadcastState();
    res.json({ ok: true });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

io.on("connection", socket => {
  socket.join("auction-room");
  socket.emit("auction:state", getPublicState());
});

async function start() {
  await mongoose.connect(process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/sgppl2");
  await seedTeams();
  server.listen(PORT, () => {
    console.log(`SGPPL-2 running on http://localhost:${PORT}`);
  });
}

start().catch(err => {
  console.error(err);
  process.exit(1);
});
